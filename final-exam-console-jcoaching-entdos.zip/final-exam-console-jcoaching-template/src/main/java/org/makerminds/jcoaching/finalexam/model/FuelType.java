package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for fuel type.
 * 
 * @author <Entela-Dostler>
 *
 */
public enum FuelType {
	// TODO define fuel type enumeration literals 
	DIESEL_FUEL,
	GASOLINE
}
