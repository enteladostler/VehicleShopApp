package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for manufacturer.
 * 
 * @author <Entela-Dostler>
 *
 */
public enum Manufacturer {
	// TODO define manufacturer enumeration literals 
	AUDI,
	BMW,
	HONDA,
	SKODA,
	VW
	
}
