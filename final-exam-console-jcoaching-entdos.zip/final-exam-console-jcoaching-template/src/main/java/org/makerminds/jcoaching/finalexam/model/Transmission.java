package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for transmission.
 * 
 * @author <Entela-Dostler>
 *
 */
public enum Transmission {
	// TODO define transmission enumeration literals 
	AUTOMATIC,
	MANUAL
}
