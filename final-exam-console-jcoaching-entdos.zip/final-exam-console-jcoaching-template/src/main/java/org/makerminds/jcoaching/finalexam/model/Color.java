package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for color.
 * 
 * @author <EntelaDostler>
 *
 */
public enum Color {
	// TODO define color enumeration literals 
	BLACK,
	BLUE,
	BROWN,
	GREY,
	RED,
	WHITE
}
